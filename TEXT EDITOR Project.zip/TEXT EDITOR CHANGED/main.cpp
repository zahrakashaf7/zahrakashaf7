#include <graphics.h>
#include "header.h"

using namespace std;
int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");
    initwindow(1500, 800, "Graphics Window"); 

    TextEditor editor;
    int choice, position;
  
    char inputBuffer[256];
    int windowWidth = 1500;  

   
    while (true) {
        cleardevice();
        editor.drawMenu();

        choice = getch() - '0';
        if (choice == 6) break;

        cleardevice();
        switch (choice) {
            case 1:
                outtextxy(100, 100, "Enter a line of text: ");
                editor.getInput(inputBuffer, 100, 140, windowWidth);
                editor.addLine(string(inputBuffer));
                break;

            case 2:
                outtextxy(100, 100, "Enter position to insert: ");
                editor.getInput(inputBuffer, 100, 140, windowWidth);
                position = atoi(inputBuffer);

                outtextxy(100, 180, "Enter a line of text: ");
                editor.getInput(inputBuffer, 100, 220, windowWidth);
                editor.insertLine(position, string(inputBuffer));
                break;

            case 3:
                outtextxy(100, 100, "Enter position to delete: ");
                editor.getInput(inputBuffer, 100, 140, windowWidth);
                position = atoi(inputBuffer);
                editor.deleteLine(position);
                break;

            case 4:
                outtextxy(100, 100, "Enter position to edit: ");
                editor.getInput(inputBuffer, 100, 140, windowWidth);
                position = atoi(inputBuffer);

                outtextxy(100, 180, "Enter new text: ");
                editor.getInput(inputBuffer, 100, 220, windowWidth);
                editor.editLine(position, string(inputBuffer));
                break;

            case 5:
                editor.displayText(100, 100, windowWidth);
                outtextxy(100, 400, "Press any key to return to the menu...");
                getch();
                break;

            default:
                outtextxy(100, 100, "Invalid choice! Press any key to try again...");
                getch();
        }
    }

    closegraph();
    return 0;
}