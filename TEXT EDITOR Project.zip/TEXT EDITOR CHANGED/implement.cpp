#include <graphics.h>
#include <iostream>
#include "header.h"

using namespace std;

void TextEditor::addLine(const string& text) {
    Node* newNode = new Node{text, nullptr};
    if (head == nullptr) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
    lineCount++;
}

void TextEditor::insertLine(int position, const string& text) {
    if (position < 1 || position > lineCount + 1) {
        cout << "Invalid position!" << endl;
        return;
    }
    Node* newNode = new Node{text, nullptr};
    if (position == 1) {
        newNode->next = head;
        head = newNode;
    } else {
        Node* temp = head;
        for (int i = 1; i < position - 1; i++) {
            temp = temp->next;
        }
        newNode->next = temp->next;
        temp->next = newNode;
    }
    lineCount++;
}

void TextEditor::deleteLine(int position) {
    if (position < 1 || position > lineCount) {
        cout << "Invalid position!" << endl;
        return;
    }
    Node* temp = head;
    if (position == 1) {
        head = head->next;
    } else {
        for (int i = 1; i < position - 1; i++) {
            temp = temp->next;
        }
        Node* toDelete = temp->next;
        temp->next = toDelete->next;
        delete toDelete;
    }
    lineCount--;
}

void TextEditor::editLine(int position, const string& newText) {
    if (position < 1 || position > lineCount) {
        cout << "Invalid position!" << endl;
        return;
    }
    Node* temp = head;
    for (int i = 1; i < position; i++) {
        temp = temp->next;
    }
    temp->line = newText;
}

void TextEditor::displayText(int x, int y, int windowWidth) {
    Node* temp = head;
    int lineHeight = 20;  
    int currentX = x;     
    int currentY = y;     
    int lineNumber = 1;   

    setcolor(WHITE);

    while (temp != nullptr) {
        string lineWithNumber = to_string(lineNumber) + ": " + temp->line;
        string wordBuffer = "";  

        for (char ch : lineWithNumber) {
            wordBuffer += ch;

            int wordWidth = textwidth(const_cast<char*>(wordBuffer.c_str()));
            
            if (currentX + wordWidth > windowWidth) {
                outtextxy(currentX, currentY, const_cast<char*>(wordBuffer.c_str()));
                
                currentX = x;
                currentY += lineHeight;

                lineNumber++;

                wordBuffer = to_string(lineNumber) + ": ";
            }
        }

        if (!wordBuffer.empty()) {
            outtextxy(currentX, currentY, const_cast<char*>(wordBuffer.c_str()));
            currentX += textwidth(const_cast<char*>(wordBuffer.c_str()));
        }

        temp = temp->next;
        lineNumber++;  
        currentX = x;  
        currentY += lineHeight;  

        if (currentY + lineHeight > getmaxy()) {
            cleardevice();  
            currentY = y;   
        }
    }
}


void TextEditor::drawMenu() {
    setcolor(YELLOW);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(150, 50, "Text Editor Menu:");
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    outtextxy(100, 120, "1. Add Line");
    outtextxy(100, 160, "2. Insert Line");
    outtextxy(100, 200, "3. Delete Line");
    outtextxy(100, 240, "4. Edit Line");
    outtextxy(100, 280, "5. Display Text");
    outtextxy(100, 320, "6. Exit");
    setcolor(LIGHTBLUE);
    outtextxy(100, 400, "Press 1, 2, 3, 4, 5, or 6 to choose an option...");
}

void TextEditor::getInput(char* inputBuffer, int x, int y, int maxWidth) {
    int i = 0;
    char ch;
    int currentX = x;  
    int currentY = y; 
	
	setcolor(WHITE); 

    while (true) {
        ch = getch();
        if (ch == '\r') {  
            inputBuffer[i] = '\0';
            break;
        } else if (ch == '\b') {  
            if (i > 0) {
                i--;
                inputBuffer[i] = '\0';

                setcolor(BLACK);
                outtextxy(currentX, currentY, "                 ");  

                currentX = x;  
                currentY = y;  
                for (int j = 0; j < i; j++) {
                    char tempBuffer[2] = {inputBuffer[j], '\0'};
                    int charWidth = textwidth(tempBuffer);
                    if (currentX + charWidth > maxWidth) {
                        currentX = x;  
                        currentY += 20;  
                    }
                    outtextxy(currentX, currentY, tempBuffer);
                    currentX += charWidth;
                }
            }
        } else {  
            inputBuffer[i++] = ch;
            inputBuffer[i] = '\0';

            char tempBuffer[2] = {ch, '\0'};
            int charWidth = textwidth(tempBuffer);

            if (currentX + charWidth > maxWidth) {
                currentX = x;  
                currentY += 20;  
            }
            outtextxy(currentX, currentY, tempBuffer);
            currentX += charWidth;
        }
    }
}

TextEditor::~TextEditor() {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}