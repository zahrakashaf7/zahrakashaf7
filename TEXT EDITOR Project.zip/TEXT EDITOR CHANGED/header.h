#ifndef HEADER_H
#define HEADER_H

using namespace std;

struct Node {
    string line;
    Node* next;
};

struct TextEditor {
    Node* head = nullptr;
    int lineCount = 0;

    void addLine(const string& text);
    void insertLine(int position, const string& text);
    void deleteLine(int position);
    void editLine(int position, const string& newText);
    void displayText(int x, int y, int windowWidth);
    void drawMenu();
    void getInput(char* inputBuffer, int x, int y, int maxWidth);
    ~TextEditor();
};

#endif